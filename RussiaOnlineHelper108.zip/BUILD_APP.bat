@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Russia Online Helper build

echo =====================================================
echo   Rossiya Online Helper - Windows application build
echo =====================================================
echo.

if not exist "index.html" (
  echo ERROR: index.html was not found in this folder.
  goto failed
)
if not exist "launcher.py" (
  echo ERROR: launcher.py was not found in this folder.
  goto failed
)
if not exist "moscow_hero.webp" (
  echo ERROR: moscow_hero.webp was not found. Re-extract the complete project archive.
  goto failed
)

set "PY_CMD="
where python >nul 2>nul
if not errorlevel 1 set "PY_CMD=python"
if not defined PY_CMD (
  where py >nul 2>nul
  if not errorlevel 1 set "PY_CMD=py"
)
if not defined PY_CMD (
  echo ERROR: Python was not found.
  echo Install Python 3.11 or 3.12 from https://www.python.org/downloads/
  echo During installation, enable Add Python to PATH.
  goto failed
)

if not exist ".venv\Scripts\python.exe" (
  if /I "%PY_CMD%"=="py" (
    py -3 -m venv .venv
  ) else (
    python -m venv .venv
  )
  if errorlevel 1 (
    echo ERROR: Could not create the virtual environment.
    echo Check your Python installation, then run this file again.
    goto failed
  )
)

call ".venv\Scripts\activate.bat"
if errorlevel 1 goto failed
python -c "import sys; print('Detected Python: ' + sys.version.split()[0]); raise SystemExit(0 if (3,11) <= sys.version_info[:2] < (3,13) else 1)"
if errorlevel 1 (
  echo ERROR: Python 3.11 or 3.12 is required.
  echo Delete the .venv folder, install Python 3.11 or 3.12 and retry.
  goto failed
)

python -m pip install --upgrade pip
if errorlevel 1 goto failed
python -m pip install pywebview pynput keyring pyinstaller
if errorlevel 1 goto failed

pyinstaller --noconfirm --clean --windowed --name "RussiaOnlineHelper" --icon "app_icon.ico" --add-data "index.html;." --add-data "app_icon.ico;." --add-data "app_icon.png;." --add-data "moscow_hero.webp;." --collect-all webview --collect-all pynput --collect-all keyring --hidden-import tkinter --hidden-import _tkinter --hidden-import keyring.backends.Windows launcher.py
if errorlevel 1 goto failed

echo.
echo BUILD SUCCEEDED.
echo EXE: %CD%\dist\RussiaOnlineHelper\RussiaOnlineHelper.exe
echo Copy the complete dist\RussiaOnlineHelper folder if moving the app to another PC.
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Read the error shown above.
pause
exit /b 1

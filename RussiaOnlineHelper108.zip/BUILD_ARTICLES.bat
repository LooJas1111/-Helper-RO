@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul
set "PY_CMD="
where python >nul 2>nul
if not errorlevel 1 set "PY_CMD=python"
if not defined PY_CMD (where py >nul 2>nul & if not errorlevel 1 set "PY_CMD=py -3")
if not defined PY_CMD (echo Python not found. Install Python 3.11/3.12 and enable Add Python to PATH. & pause & exit /b 1)
%PY_CMD% build_articles.py
if errorlevel 1 (echo. & echo BUILD FAILED & pause & exit /b 1)
echo.
echo Next: run BUILD_APP.bat to rebuild the application.
pause

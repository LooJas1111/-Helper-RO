# -*- coding: utf-8 -*-
r"""
Сборка базы статей «Россия Онлайн Хэлпер».

Как пользоваться:
  1. Положи текстовые файлы законов в папку  texts\  рядом с этим файлом
     (формат .txt, кодировка UTF-8; имена любые — тип закона определяется по заголовку).
  2. Запусти BUILD_ARTICLES.bat  (или:  python build_articles.py).
  3. Скрипт ПОЛНОСТЬЮ заменяет старые статьи: пишет articles.json и встраивает новую базу в index.html.
     Ключи локального хранилища меняются, поэтому старые статьи в приложении не «всплывут» снова.
  4. Пересобери приложение (BUILD_APP.bat).

Для каждой статьи создаётся:
  d        — краткое содержание (показывается на карточках и в оверлее)
  fullText — полный текст статьи (показывается при открытии статьи)
Нужны только стандартные библиотеки Python.
"""
import datetime
import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TEXTS_DIR = os.path.join(HERE, "texts")
CODES = ["uk", "pk", "koap", "pdd", "tk", "eth", "fkz", "con"]
DOC_NAMES = {
    "uk": "Уголовный кодекс РО",
    "pk": "Уголовно-процессуальный кодекс РО",
    "koap": "Кодекс об административных правонарушениях РО",
    "pdd": "Правила дорожного движения РО",
    "tk": "Трудовой кодекс РО",
    "eth": "Федеральный кодекс этики и служебного поведения государственных служащих",
    "fkz": "ФКЗ «О судебной системе РО»",
    "con": "Конституция Российского Округа",
}
CATEGORY = {"uk": "УК РО", "pk": "ПК РО", "koap": "КоАП РО", "pdd": "ПДД РО", "tk": "ТК РО",
            "eth": "Кодекс этики РО", "fkz": "ФКЗ суды РО", "con": "Конституция РО"}

# ------------------------------------------------------------------ чистка текста
NOISE_EXACT = {
    "Сияй с нами на Россия Онлайн", "LikeЖалоба", "Like Жалоба", "Добавить закладку",
    "Юлиан Сакрадов", "Лидер Правительства", "Лидер государственной организации",
    "Содержание", "Обозначения",
}
NOISE_RE = [
    re.compile(r"^AD_4nX[\w\-]+$"),
    re.compile(r"^#\d+$"),
    re.compile(r"^\d{2}\.\d{2}\.\d{4}$"),
    re.compile(r"^[\d.\s]+$"),                    # подписи под картинками: «5.3.1 5.3.2»
    re.compile(r"^Посмотреть вложение\s*\d+(\s*Посмотреть вложение\s*\d+)*$"),
    re.compile(r"^(Утратил[аи]?|Утрачено)\s+силу\.?$"),
]


def clean_line(line):
    line = line.replace("\u200b", "").replace("\ufeff", "").replace("\xa0", " ")
    line = re.sub(r"AD_4nX[\w\-]+", "", line)
    line = re.sub(r"Посмотреть вложение\s*\d+", "", line)
    line = re.sub(r"[ \t]+", " ", line).strip()
    return line


def clean_lines(text):
    out = []
    for raw in text.splitlines():
        ln = clean_line(raw)
        if not ln or ln in NOISE_EXACT or any(r.match(ln) for r in NOISE_RE):
            continue
        out.append(ln)
    return out


# ------------------------------------------------------------------ определение типа файла
def detect_code(name, text):
    base = os.path.splitext(os.path.basename(name))[0].lower()
    if base in CODES:
        return base
    head = text[:600].upper().replace("Ё", "Е")
    rules = [
        ("pk", "УГОЛОВНО-ПРОЦЕССУАЛЬН"), ("koap", "АДМИНИСТРАТИВНЫХ ПРАВОНАРУШЕНИ"),
        ("uk", "УГОЛОВНЫЙ КОДЕКС"), ("pdd", "ПРАВИЛА ДОРОЖНОГО ДВИЖЕНИЯ"),
        ("tk", "ТРУДОВОЙ КОДЕКС"), ("eth", "КОДЕКС ЭТИКИ"), ("fkz", "СУДЕБНОЙ СИСТЕМЕ"),
        ("con", "КОНСТИТУЦИЯ"),
    ]
    for code, key in rules:
        if key in head:
            return code
    return None


# ------------------------------------------------------------------ краткое содержание / заголовки
ABBR = {"ст", "ч", "п", "пп", "см", "т", "г", "гг", "им", "др", "пр", "тыс", "руб", "РО", "№"}


def split_sentences(text):
    parts, start = [], 0
    for m in re.finditer(r"[.!?;](?=\s+(?:[А-ЯЁA-Z«\"(\d—-]))", text):
        end = m.end()
        last = re.findall(r"(\S+)$", text[start:end])
        tok = last[0].rstrip(".!?;") if last else ""
        if text[end - 1] == "." and (tok in ABBR or len(tok) <= 1):
            continue
        parts.append(text[start:end].strip())
        start = end
    tail = text[start:].strip()
    if tail:
        parts.append(tail)
    return parts


def cut_words(text, limit):
    text = text.strip()
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].rstrip(",;:—- ")
    return cut + "…"


def strip_marks(text):
    text = re.sub(r"\[[РФВ/]+\]\s*", "", text)
    text = re.sub(r"\[\s*★+(?:\s*до\s*★+)?\s*\]\s*", "", text)
    text = re.sub(r"\[от ★ до ★+\]\s*", "", text)
    return text.strip()


def strip_numbering(text):
    return re.sub(r"^(?:ч\.\s*)?\d+(?:\.\d+)*[.)]?\s+(?=[А-ЯЁA-Z«\"(])", "", text).strip()


def strip_see_ref(text):
    return re.sub(r"\s*\(см\.[^)]*\)", "", text).strip()


def derive_title(text, limit=80):
    text = strip_numbering(strip_marks(text))
    text = strip_see_ref(text)
    text = re.sub(r"\s*\([^)]{0,60}\)", "", text) if len(text) > limit else text
    first = split_sentences(text)[0] if text else ""
    first = re.split(r":\s", first + " ")[0]
    first = first.rstrip(".:;, ")
    first = cut_words(first, limit)
    return first[:1].upper() + first[1:] if first else "Без названия"


def make_summary(lines, limit=230):
    """Краткое содержание: 1-2 первых предложения без номеров частей, отметок и санкции."""
    chunks, total = [], 0
    for ln in lines:
        ln = strip_marks(ln)
        if re.match(r"^(Штраф|Предупреждение|Наказание:|Утратил|\(см\.)", ln):
            continue
        ln = strip_numbering(ln)
        cut = False
        m = re.search(r"\s*[,;]?\s+[-—]\s+наказыва\w+.*$", ln)
        if m:
            ln, cut = ln[:m.start()].rstrip(" ,;-—"), True
        elif re.match(r"^[-—]\s*наказыва", ln):
            break
        if not ln:
            continue
        if not re.search(r"[.!?:;…]$", ln):
            ln += "."
        chunks.append(ln)
        total += len(ln)
        if (cut and total >= 30) or total > 420:
            break
    text = " ".join(chunks).strip()
    if not text:
        return ""
    sents = split_sentences(text)
    out, idx = sents[0], 0
    while (len(out) < 90 or out.endswith(":")) and idx + 1 < len(sents) and len(out) < limit:
        idx += 1
        out += " " + sents[idx]
    out = out.strip()
    if len(out) > limit:
        out = cut_words(out, limit - 1)
    if not re.search(r"[.!?:;…]$", out):
        out += "."
    return out


def extract_punishment(code, body_lines):
    joined = " ".join(body_lines)
    marks = re.search(r"\[(★+)\]", joined)
    stars = marks.group(1) if marks else ""
    if code == "koap":
        found = [ln.rstrip(".") for ln in body_lines if re.match(r"^(Штраф|Предупреждение)", ln)]
        return " / ".join(dict.fromkeys(found))[:260]
    if code == "eth":
        found = [re.sub(r"^Наказание:\s*", "", ln).rstrip(".") for ln in body_lines if ln.startswith("Наказание:")]
        return "; ".join(dict.fromkeys(found[:2]))
    if code in ("uk",):
        pats = re.findall(r"наказыва\w+\s+(.*?)(?:\.\s|\.$|$)", joined)
        pats = [p.strip(" -—,;") for p in pats if p.strip()]
        res = "; ".join(dict.fromkeys(pats[:3]))
        if res and stars:
            res += f" · розыск {stars}"
        return cut_words(res, 260)
    return ""


# ------------------------------------------------------------------ разбор «Статья N.»
ART_RE = re.compile(r"^Статья\s+(\d+(?:\.\d+)*)\.?\s*(.*)$")
CHAPTER_RE = re.compile(r"^(?:ПДД РО,\s*)?Глава\s+(\d+(?:\.\d+)*)\.?\s*(.*)$", re.I)
SECTION_RE = re.compile(r"^(?:РАЗДЕЛ|Раздел)\s+([IVXLC]+)\.?\s*(.*)$")
PART_RE = re.compile(r"^(?:ЧАСТЬ|Часть)\s+[А-ЯЁа-яё]+\.?\s*.*$")


def looks_like_subheading(line, next_line):
    if not next_line or not (next_line.startswith("Статья ") or next_line.startswith("Глава ")):
        return False
    if len(line) > 70 or re.search(r"[.;:,]$", line):
        return False
    if re.match(r"^(\d|[-—•]|ч\.|Примечание|Пункт|Исключение)", line) or line.upper() == line:
        return False
    return True


def parse_articles(code, lines):
    arts, chapter, section, sub = [], "", "", ""
    cur = None

    def flush():
        nonlocal cur
        if cur:
            arts.append(cur)
        cur = None

    def chapter_label():
        base = chapter or section
        if sub:
            return (base.rstrip(".") + " — " + sub) if base else sub
        return base

    i = 0
    while i < len(lines):
        ln = lines[i]
        nxt = lines[i + 1] if i + 1 < len(lines) else ""

        if not ART_RE.match(ln):
            m = CHAPTER_RE.match(ln)
            if m:
                flush()
                title = m.group(2).strip()
                if not title and nxt and not ART_RE.match(nxt) and not CHAPTER_RE.match(nxt):
                    title = nxt
                    i += 1
                chapter = (f"Глава {m.group(1)}. {title}" if title else f"Глава {m.group(1)}").strip()
                sub = ""
                i += 1
                continue
            m = SECTION_RE.match(ln)
            if m:
                flush()
                title = m.group(2).strip()
                if not title and nxt and not ART_RE.match(nxt) and not CHAPTER_RE.match(nxt):
                    title = nxt
                    i += 1
                if title.isupper():
                    title = title.capitalize()
                section = f"Раздел {m.group(1)}. {title}".strip()
                chapter, sub = "", ""
                i += 1
                continue
            if PART_RE.match(ln) and ln.upper() == ln:
                flush()
                i += 1
                continue

        m = ART_RE.match(ln)
        if m:
            flush()
            num, head = m.group(1), m.group(2).strip()
            body, title, derived, alt = [], "", False, ""
            ref = re.search(r"\s*(\(см\.[^)]*\))\.?$", head)
            head_c = strip_see_ref(head).rstrip(".") if ref else head.rstrip(".")
            simple = (head_c and len(head_c) <= 100 and not re.search(r"[.;:]\s", head_c + " ")
                      and not head_c.endswith(":") and " - " not in head_c and head_c.count(",") <= 1)
            if simple:
                title = head_c
                if ref:
                    body.append(ref.group(1))
            elif head:
                two = re.match(r"^(.{3,110}?)\.\s+([^.]{3,110})\.?$", head)
                if code == "pk" and two and two.group(1).count(",") <= 1:
                    title, alt = two.group(1), head.rstrip(".")
                else:
                    body.append(head)
                    derived = True
            cur = {"n": num, "title": title, "body": body, "chapter": chapter_label(),
                   "derived": derived, "alt": alt}
            i += 1
            continue

        if looks_like_subheading(ln, nxt):
            flush()
            sub = ln.rstrip(".")
            i += 1
            continue
        if cur is not None:
            cur["body"].append(ln)
        i += 1
    flush()
    return finalize(code, arts)


# ------------------------------------------------------------------ разбор ПДД
POINT2_RE = re.compile(r"^(\d{1,2}\.\d{1,2})\.?\s+(\S.*)$")
POINTN_RE = re.compile(r"^(\d{1,2}\.\d{1,2}(?:\.\d{1,2})+)\.?\s+(\S.*)$")
PDD_CHAPTER_RE = re.compile(r"^(\d{1,2})\.\s+([А-ЯЁ][^;]*[^.;:,\s])$")
SIGN_RE = re.compile(r"^Знак[и]?\s+\d")
MARK_RE = re.compile(r"^Разметка\s+\d")
SIGN_SECTIONS = {"Дорожные знаки", "Дорожная разметка", "Горизонтальная разметка", "Вертикальная разметка"}


def sign_header(line):
    kind = "Знак" if line.startswith("Знак") else "Разметка"
    rest = re.sub(r"^(Знак[и]?|Разметка)\s+", "", line)
    nums = re.match(r"^(\d+(?:\.\d+)*)", rest)
    num = nums.group(1) if nums else ""
    t = rest
    while True:
        t2 = re.sub(r"^(?:Знак[и]?\s+)?[\d.]+[.,]?\s*(?:и\s+|–\s*|-\s*)?", "", t)
        if t2 == t:
            break
        t = t2
    return f"{kind} {num}".strip(), t.strip().rstrip(".")


def parse_pdd(lines):
    arts, cur, chapter, signs_mode, seen = [], None, "", False, {}

    def flush():
        nonlocal cur
        if cur:
            arts.append(cur)
        cur = None

    for ln in lines:
        base = ln.rstrip(".")
        if base in SIGN_SECTIONS:
            flush()
            signs_mode = True
            chapter = base
            continue
        m = CHAPTER_RE.match(ln)
        if m and not signs_mode:
            flush()
            chapter = f"Глава {m.group(1)}. {m.group(2).strip()}".rstrip(". ") + "."
            continue
        m = PDD_CHAPTER_RE.match(ln)
        if m and len(ln) <= 110:
            flush()
            chapter = f"{m.group(1)}. {m.group(2).strip()}" if signs_mode else f"Глава {m.group(1)}. {m.group(2).strip()}"
            continue
        if signs_mode and (SIGN_RE.match(ln) or MARK_RE.match(ln)):
            flush()
            n, title = sign_header(ln)
            seen[n] = seen.get(n, 0) + 1
            if seen[n] > 1:
                n = f"{n} ({seen[n]})"
            cur = {"n": n, "title": title, "body": [], "chapter": chapter, "derived": False, "alt": ""}
            continue
        if not signs_mode:
            m = POINTN_RE.match(ln)
            if m and cur:
                cur["body"].append(f"{m.group(1)}. {m.group(2)}")
                continue
            m = POINT2_RE.match(ln)
            if m:
                flush()
                n = m.group(1)
                seen[n] = seen.get(n, 0) + 1
                if seen[n] > 1:  # в оглавлении/тексте номер мог повториться
                    n = f"{n} ({seen[n]})"
                cur = {"n": n, "title": "", "body": [m.group(2)], "chapter": chapter, "derived": True, "alt": ""}
                continue
        if cur:
            cur["body"].append(ln)
    flush()
    return finalize("pdd", arts)


# ------------------------------------------------------------------ финализация записей
def finalize(code, arts):
    out, used = [], {}
    for a in arts:
        body = [b for b in a["body"] if b]
        derived = a.get("derived") and body
        title = a["title"] or (derive_title(body[0]) if body else f"Статья {a['n']}")
        n = a["n"]
        used[n] = used.get(n, 0) + 1
        if used[n] > 1:
            n = f"{n} ({used[n]})"
        label = n if code == "pdd" else "Статья " + n
        if derived:
            head_text, rest = body[0], body[1:]
            summary_src = body
        else:
            head_text, rest = (a.get("alt") or title), body
            summary_src = body
        parts = []
        if a.get("chapter"):
            parts.append(a["chapter"] + "\n")
        parts.append(f"{label}. {head_text}")
        parts.extend(rest)
        full = "\n".join(parts).strip()
        summary = make_summary(summary_src) or (title if title.endswith((".", "…")) else title + ".")
        if summary.rstrip(".…") == title.rstrip(".…") and not derived and body:
            summary = make_summary(body) or title
        punish = extract_punishment(code, body)
        keywords = " ".join([DOC_NAMES[code], CATEGORY[code], a.get("chapter", ""), title, full])
        out.append({
            "n": n, "t": title, "d": summary, "p": punish,
            "k": re.sub(r"\s+", " ", keywords)[:1500],
            "fullText": full, "document": DOC_NAMES[code],
            "chapter": a.get("chapter", ""), "originalCategory": CATEGORY[code],
        })
    return out


# ------------------------------------------------------------------ main
def build(texts_dir):
    files = sorted(glob.glob(os.path.join(texts_dir, "*.txt")))
    if not files:
        raise SystemExit(f"В папке {texts_dir} нет .txt файлов. Положи туда тексты законов и запусти снова.")
    result, report = {c: [] for c in CODES}, []
    for path in files:
        text = open(path, encoding="utf-8-sig", errors="replace").read()
        code = detect_code(path, text)
        if not code:
            report.append(f"ПРОПУЩЕН (не определён тип): {os.path.basename(path)}")
            continue
        lines = clean_lines(text)
        arts = parse_pdd(lines) if code == "pdd" else parse_articles(code, lines)
        result[code].extend(arts)
        report.append(f"{os.path.basename(path)} -> {code}: {len(arts)} статей")
    return result, report


def js_safe(obj):
    s = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
    return s.replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")


def embed(index_path, data):
    html = open(index_path, encoding="utf-8").read()
    start = html.index("var DEMO=")
    end = html.index("\n", start)
    html = html[:start] + "var DEMO=" + js_safe(data) + ";" + html[end:]
    stamp = datetime.datetime.now().strftime("%Y%m%d%H%M")
    html = re.sub(r"rolh_(articles|favs|recent)_\d+", lambda m: f"rolh_{m.group(1)}_{stamp}", html)
    open(index_path, "w", encoding="utf-8").write(html)
    return stamp


def main():
    texts_dir = sys.argv[1] if len(sys.argv) > 1 else TEXTS_DIR
    index_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "index.html")
    json_path = os.path.join(os.path.dirname(index_path), "articles.json")
    data, report = build(texts_dir)
    total = sum(len(v) for v in data.values())
    if total == 0:
        raise SystemExit("Статьи не найдены — старая база НЕ тронута.")
    json.dump(data, open(json_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    stamp = embed(index_path, data)
    print("\n".join(report))
    print("-" * 50)
    for c in CODES:
        print(f"{c:5} {len(data[c])}")
    print(f"ВСЕГО: {total}. Новая версия хранилища: {stamp}")
    print("Готово. Теперь запусти BUILD_APP.bat, чтобы пересобрать приложение.")


if __name__ == "__main__":
    main()
